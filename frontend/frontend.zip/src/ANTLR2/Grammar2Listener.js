// Generated from Grammar2.g4 by ANTLR 4.13.1
// jshint ignore: start
import antlr4 from 'antlr4';

// This class defines a complete listener for a parse tree produced by Grammar2Parser.
export default class Grammar2Listener extends antlr4.tree.ParseTreeListener {

	// Enter a parse tree produced by Grammar2Parser#condition.
	enterCondition(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#condition.
	exitCondition(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#equalBExpr.
	enterEqualBExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#equalBExpr.
	exitEqualBExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#disjuctionBExpr.
	enterDisjuctionBExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#disjuctionBExpr.
	exitDisjuctionBExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#compareBExpr.
	enterCompareBExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#compareBExpr.
	exitCompareBExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#booleanExpr.
	enterBooleanExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#booleanExpr.
	exitBooleanExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#conjuctionBExpr.
	enterConjuctionBExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#conjuctionBExpr.
	exitConjuctionBExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#notBExpr.
	enterNotBExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#notBExpr.
	exitNotBExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#parenthesesBExpr.
	enterParenthesesBExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#parenthesesBExpr.
	exitParenthesesBExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#varExpr.
	enterVarExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#varExpr.
	exitVarExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#numberExpr.
	enterNumberExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#numberExpr.
	exitNumberExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#plusMinusExpr.
	enterPlusMinusExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#plusMinusExpr.
	exitPlusMinusExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#multDivExpr.
	enterMultDivExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#multDivExpr.
	exitMultDivExpr(ctx) {
	}


	// Enter a parse tree produced by Grammar2Parser#parenthesesExpr.
	enterParenthesesExpr(ctx) {
	}

	// Exit a parse tree produced by Grammar2Parser#parenthesesExpr.
	exitParenthesesExpr(ctx) {
	}



}