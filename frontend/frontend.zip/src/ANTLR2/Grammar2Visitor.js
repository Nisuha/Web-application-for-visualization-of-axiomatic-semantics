// Generated from Grammar2.g4 by ANTLR 4.13.1
// jshint ignore: start
import antlr4 from 'antlr4';

// This class defines a complete generic visitor for a parse tree produced by Grammar2Parser.

export default class Grammar2Visitor extends antlr4.tree.ParseTreeVisitor {

	// Visit a parse tree produced by Grammar2Parser#condition.
	visitCondition(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#equalBExpr.
	visitEqualBExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#disjuctionBExpr.
	visitDisjuctionBExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#compareBExpr.
	visitCompareBExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#booleanExpr.
	visitBooleanExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#conjuctionBExpr.
	visitConjuctionBExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#notBExpr.
	visitNotBExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#parenthesesBExpr.
	visitParenthesesBExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#varExpr.
	visitVarExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#numberExpr.
	visitNumberExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#plusMinusExpr.
	visitPlusMinusExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#multDivExpr.
	visitMultDivExpr(ctx) {
	  return this.visitChildren(ctx);
	}


	// Visit a parse tree produced by Grammar2Parser#parenthesesExpr.
	visitParenthesesExpr(ctx) {
	  return this.visitChildren(ctx);
	}



}